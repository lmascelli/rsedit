use crate::lisp::{LispExp, Env, EvalError, eval};

pub fn primitive_funcall<T>(args: &[LispExp<T>], ctx: &mut T) -> Result<LispExp<T>, EvalError>
where
    T: Clone + PartialEq + std::fmt::Debug
{
    if args.is_empty() {
        return Err(EvalError::WrongNumberOfArguments { expected: 1, got: 0 });
    }
    
    // Because funcall is a normal primitive, its arguments are already evaluated.
    // args[0] is the Lambda object itself, args[1..] are the arguments passed to it.
    let func_obj = &args[0];
    let func_args = &args[1..];

    match func_obj {
        LispExp::Lambda(lambda) => {
            if lambda.params.len() != func_args.len() {
                return Err(EvalError::WrongNumberOfArguments {
                    expected: lambda.params.len(),
                    got: func_args.len(),
                });
            }
            let call_frame = Env::new_child(&lambda.env);
            for (i, param_name) in lambda.params.iter().enumerate() {
                call_frame.set_variable(param_name.clone(), func_args[i].clone());
            }
            eval(&lambda.body, call_frame, ctx)
        }
        LispExp::Primitive(func) => func(func_args, ctx),
        _ => Err(EvalError::UncorrectFunctionDefinition),
    }
}

pub fn setup_base_env<T>(env: std::sync::Arc<Env<T>>)
where
    T: Clone + std::fmt::Debug + PartialEq
{
    env.set_function("funcall".into(), LispExp::Primitive(primitive_funcall));
}
